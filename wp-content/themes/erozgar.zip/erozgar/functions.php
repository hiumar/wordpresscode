<?php

// function pro_fetch_scripts(){
// //styles files
// 	wp_enqueue_style('style',get_stylesheet_uri());
// 	wp_enqueue_style('bootstrap',get_template_directory_uri().'/wordify/css/bootstrap.css');
// 	wp_enqueue_style('style',get_template_directory_uri().'/wordify/css/style.css');
// 	wp_enqueue_style('font',get_template_directory_uri().'/wordify/css/animate.css');
// 	wp_enqueue_style('animate',get_template_directory_uri().'/wordify/css/owl.carousel.min.css');
// 	wp_enqueue_style('owl',get_template_directory_uri().'/wordify/css/owl.carousel.min.css');
// 	wp_enqueue_style('css_theme',get_template_directory_uri().'/wordify/fonts/ionicons/css/ionicons.min.css');
// 	wp_enqueue_style('default',get_template_directory_uri().'/wordify/fonts/fontawesome/css/font-awesome.min.css');
// 	wp_enqueue_style('bootstrap',get_template_directory_uri().'/wordify/fonts/flaticon/font/flaticon.css');
// /// scripts file


// 	wp_enqueue_script('jquery-3.2.1.min.js',get_template_directory_uri().'/wordify/js/jquery-3.2.1.min.js',array(),'1.1',false);
// 	wp_enqueue_script('jquery-migrate-3.0.0',get_template_directory_uri().'/wordify/js/jquery-migrate-3.0.0.js',array(),'3',false);
// 	wp_enqueue_script('popper',get_template_directory_uri().'/wordify/js/popper.min.js',array(),'1.2',false);
// 	wp_enqueue_script('bootstrap',get_template_directory_uri().'/wordify/js/bootstrap.min.js',array(),'1.1',false;
// 	wp_enqueue_script('carousel',get_template_directory_uri().'/wordify/js/owl.carousel.min.js',array(),'1.1',false);
// 	wp_enqueue_script('waypoints',get_template_directory_uri().'/wordify/js/jquery.waypoints.min.js',array(),'1.1',false);
// 	wp_enqueue_script('jquery.stellar',get_template_directory_uri().'/wordify/js/jquery.stellar.min.js',array(),'1.1',false);
    
 
//    //add_action('wp_enqueue_style','pro_fetch_scripts');

 
// }
//    add_action('wp_enqueue_scripts','pro_fetch_scripts'); 


add_theme_support('post-thumbnails');

?>